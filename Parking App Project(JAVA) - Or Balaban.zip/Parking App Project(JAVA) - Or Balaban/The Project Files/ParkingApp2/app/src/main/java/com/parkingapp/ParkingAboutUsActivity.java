package com.parkingapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Objects;

//this class is for presenting the information page about the app
public class ParkingAboutUsActivity extends AppCompatActivity {

    //TODO:Add Media Player And LinkedIn link!
    TextView devDetails,aboutUsDetails;
    Button linkedinBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_us);
        Objects.requireNonNull(getSupportActionBar()).setTitle("About Us Page");

        devDetails = findViewById(R.id.txtDevBioDetails);



        aboutUsDetails = findViewById(R.id.txtAboutUsDetails);



        linkedinBtn = findViewById(R.id.buttonLinkedin);
        linkedinBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(ParkingAboutUsActivity.this,"(Link To Linkedin Page)",Toast.LENGTH_LONG).show();
                finish();
            }
        });

    }
}
