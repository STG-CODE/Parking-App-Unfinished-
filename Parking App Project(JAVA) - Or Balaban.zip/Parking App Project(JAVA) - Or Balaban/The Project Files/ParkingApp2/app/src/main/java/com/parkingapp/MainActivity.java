package com.parkingapp;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.PopupMenu;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationAvailability;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnSuccessListener;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Objects;

public class MainActivity extends AppCompatActivity implements OnMapReadyCallback,PopupMenu.OnMenuItemClickListener,
        GoogleApiClient.ConnectionCallbacks,GoogleApiClient.OnConnectionFailedListener,LocationListener {



    private static final int ALL_PERMISSIONS_RESULT = 1111;
    //Default Details for user
    private final String DEFAULT_FIRST_NAME = "Yosi";
    private final String DEFAULT_LAST_NAME = "Cohen";
    private final String DEFAULT_CAR_MODEL = "Honda";
    private final String DEFAULT_CAR_ID = "11-222-33";

    //Default Details Of Location
    private final String DEFAULT_CITY_NAME = "Rishon Lezion";
    private final String DEFAULT_STREET_NAME = "Knion Hari Hhof";
    private final String DEFAULT_PARKING_NAME = "Mihlla Lminhal Parking Spot";

    //used to for our "shared preferences" variable
    SharedPreferences sharedPreferences;

    //our location import variables
    LocationManager locationManager;
    LocationListener locationListener;

    //the google map view
    MapView mapView;
    private GoogleMap mMap;

    //used to save the users current position
    double latitude, longitude;
    //
    private GoogleApiClient client;
    private FusedLocationProviderClient fusedLocationProviderClient;
    private ArrayList<String> permissionsToRequest;
    private ArrayList<String> permissions = new ArrayList<>();
    private ArrayList<String> permissionsRejected = new ArrayList<>();

    @SuppressLint({"UseSwitchCompatOrMaterialCode", "WrongViewCast"})
//    private final Button autoRefreshButton = findViewById(R.id.switchRefresh);

    //User Details
    TextView userDetails, userLocationDetails;
    private String firstName;
    private String lastName;
    private String carModel;
    private String carID;

    //is refresh option on?//TODO:need to implement
    private boolean isAutoRefreshOn = false;
    public LocationRequest locationRequest;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Objects.requireNonNull(getSupportActionBar()).setTitle("Main Parking App Page");

        //start our location client
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(MainActivity.this);
        locationManager = (LocationManager)getSystemService(Context.LOCATION_SERVICE);

        //collect permissions
        permissions.add(Manifest.permission.ACCESS_FINE_LOCATION);
        permissions.add(Manifest.permission.ACCESS_COARSE_LOCATION);
        permissionsToRequest = permissionsToRequest(permissions);


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
            if (permissionsToRequest.size() > 0){
                requestPermissions(permissionsToRequest.toArray(
                        new String[permissionsToRequest.size()]),
                        ALL_PERMISSIONS_RESULT
                );
            }
        }

        //start our client
        client = new GoogleApiClient.Builder(this)
                .addApi(LocationServices.API)
                .addOnConnectionFailedListener(this)
                .addConnectionCallbacks(this)
                .build();

//        SupportMapFragment mapFragment = (SupportMapFragment)getSupportFragmentManager()
//                .findFragmentById(R.id.mapViewCurrentUserLocal);
//        mapFragment.getMapAsync(this);

        //our connection to the map in the page
        mapView = findViewById(R.id.mapViewCurrentUserLocal);
        mapView.getMapAsync(this);
        mapView.onCreate(savedInstanceState);


        //user details presenter section
        userDetails = findViewById(R.id.txtUserAndCarDetails);

        //where our data is stored from the "settings page"
        Intent intentUserDetails = getIntent();
        firstName = intentUserDetails.getStringExtra("userFirstName");
        lastName = intentUserDetails.getStringExtra("userLastName");
        carModel = intentUserDetails.getStringExtra("userCarModel");
        carID = intentUserDetails.getStringExtra("userCarID");

        //the presentation of the users details
        userDetails.setText("First Name : " + firstName +
                        "\nLast Name : " + lastName +
                        "\nCar Model : " + carModel +
                        "\nCar ID : " + carID);

        //TODO:trying to set default details but need to find out how to do
        // so while letting it change when user enters his details.
//        if (firstName == null && lastName == null && carModel == null && carID == null) {
//            firstName = DEFAULT_FIRST_NAME;
//            lastName = DEFAULT_LAST_NAME;
//            carModel = DEFAULT_CAR_MODEL;
//            carID = DEFAULT_CAR_ID;
//        }


        //user location details section

        //TODO: try to implement a bar for monitoring timer for refresh of location
        //ProgressBar autoRefreshTimer = findViewById(R.id.progressBarRefreshTime);
        //Thread thread = new Thread(new Runnable() {
        //    @Override
        //    public void run() {
        //        if (isAutoRefreshOn){
        //            for (int time = 0 ; time < 10 ; time++){
        //                autoRefreshTimer.incrementProgressBy(10);
        //                SystemClock.sleep(500);
        //            }
        //        }
        //    }
        //});
        //thread.start();


        //switch section for refresh of location
        @SuppressLint("UseSwitchCompatOrMaterialCode") Switch autoRefreshSwitch = findViewById(R.id.switchRefresh);
        autoRefreshSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean switchOn) {
                if (switchOn){
                    isAutoRefreshOn = true;
                    Toast.makeText(MainActivity.this,"Auto Refresh Is Activated",Toast.LENGTH_SHORT).show();
                } else {
                    isAutoRefreshOn = false;
                    Toast.makeText(MainActivity.this,"Auto Refresh Is Disabled",Toast.LENGTH_SHORT).show();
                }
            }
        });

        //the settings button
        Button settingsButton = findViewById(R.id.buttonUpdatePersInfo);
        settingsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                goToSettings();
            }
        });


//        locationListener = new LocationListener() {
//            @Override
//            public void onLocationChanged(@NonNull Location location) {
//
//                latitude = location.getLatitude();
//                longitude = location.getLongitude();
//                String city = null;
//                String street = null;
//                String streetNum = null;
//                Log.e("latitude : ",String.valueOf(latitude));
//                Log.e("longitude : ",String.valueOf(longitude));
//            }
//        };
//        if (ContextCompat.checkSelfPermission
//                (this, Manifest.permission.ACCESS_FINE_LOCATION)
//                != PackageManager.PERMISSION_GRANTED){
//            ActivityCompat.requestPermissions(this,new String[] {Manifest.permission.ACCESS_FINE_LOCATION},1);
//        } else {
//            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,500,50,locationListener);
//        }

        //TODO:finish implementing shared preferences
//        retrieveData();

    }

    //used to collect the permissions to request access to
    private ArrayList<String> permissionsToRequest(ArrayList<String> wantedPermissions) {
        ArrayList<String> result = new ArrayList<>();

        for(String permission : wantedPermissions){
            if (!hasPermission(permission)){
                result.add(permission);
            }
        }
        return result;
    }

    //checks if the given permission is granted
    private boolean hasPermission(String permission) {
        return checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED;
    }

    //TODO:need to find out how to get location after start of app and not after moving between activity
    @Override
    protected void onStart() {
        super.onStart();
        if (client != null){
            client.connect();
        }
        mapView.onStart();
    }

    @Override
    protected void onPostResume() {
        super.onPostResume();
        checkClientServices();
        mapView.onResume();
    }

    @Override
    protected void onStop() {
        super.onStop();
        client.disconnect();
        mapView.onStop();
    }

    @Override
    protected void onPause(){
        super.onPause();
        mapView.onPause();

        //TODO:finish this part of shared preferences
//        saveData();

        if (client != null && client.isConnected()){
            LocationServices.getFusedLocationProviderClient(this)
                    .removeLocationUpdates(new LocationCallback() {});
            client.disconnect();
        }

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mapView.onDestroy();
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        mapView.onSaveInstanceState(outState);
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        mapView.onLowMemory();
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;
        //our current location
        LatLng currentLocation = new LatLng(latitude,longitude);//TODO: test this when API KEY works
        mMap.addMarker(new MarkerOptions().position(currentLocation).title("Your Current Position"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(currentLocation));
    }

    //checks the clients services
    private void checkClientServices(){
        int errorCode = GoogleApiAvailability.getInstance()
                .isGooglePlayServicesAvailable(this);

        if (errorCode != ConnectionResult.SUCCESS){
            Dialog errorDialog = GoogleApiAvailability.getInstance()
                    .getErrorDialog(this, errorCode, errorCode, new DialogInterface.OnCancelListener() {

                        @Override
                        public void onCancel(DialogInterface dialog) {
                            Toast.makeText(MainActivity.this,"No Services",Toast.LENGTH_LONG).show();
                            finish();
                        }
                    });
            assert errorDialog != null;
            errorDialog.show();
        } else {
            Log.println(Log.INFO,"no update needed","App Is Up To Date");
        }
    }



    @Override
    public void onConnected(@Nullable Bundle bundle) {
        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED )
        {
            return;
        }
        fusedLocationProviderClient.getLastLocation()
                .addOnSuccessListener(this, new OnSuccessListener<Location>() {
                    @Override
                    public void onSuccess(Location location) {
                        //get last known location but can also be null
                        if (location != null){
                            userLocationDetails.setText(
                                    MessageFormat.format("Lat: {0} Lon: {1}",
                                            location.getLatitude(), location.getLongitude()));
                        }
                    }
                });
        startLocationUpdates();
    }

    //makes sure and is used for updating current location
    private void startLocationUpdates() {
        locationRequest = new LocationRequest();
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        //todo:replace with manual choice of user if refresh location or not
        locationRequest.setInterval(5000);
        locationRequest.setFastestInterval(5000);
        userLocationDetails = findViewById(R.id.txtUserLocationDetails);

        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED)
        {
            Toast.makeText(MainActivity.this,"You Need To Enable Permissions To Display Location",Toast.LENGTH_LONG).show();
        }

        LocationServices.getFusedLocationProviderClient(MainActivity.this)
                .requestLocationUpdates(locationRequest, new LocationCallback() {

                    @Override
                    public void onLocationResult(@NonNull LocationResult locationResult) {
                        super.onLocationResult(locationResult);

                        if (locationResult != null){
                            Location location = locationResult.getLastLocation();

                                userLocationDetails.setText(
                                        MessageFormat.format("Lat: {0} Lon: {1}",
                                                location.getLatitude(), location.getLongitude()));
                        }
                    }

                    @Override
                    public void onLocationAvailability(@NonNull LocationAvailability locationAvailability) {
                        super.onLocationAvailability(locationAvailability);
                    }
                },null);

    }

    //checks , asks and verifies that the user enabled the needed permissions
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        switch (requestCode){
            case ALL_PERMISSIONS_RESULT:
                for (String permission : permissionsToRequest){
                    if (!hasPermission(permission)){
                        permissionsRejected.add(permission);
                    }
                }
                if (permissionsRejected.size() > 0){
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
                        if (shouldShowRequestPermissionRationale(permissionsRejected.get(0))){
                            new AlertDialog.Builder(MainActivity.this)
                                    .setMessage("These Permissions Are Needed To Get Location")
                                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
                                                requestPermissions(permissionsRejected.toArray(
                                                        new String[permissionsRejected.size()]),ALL_PERMISSIONS_RESULT);
                                            }
                                        }
                                    }).setNegativeButton("Cancel",null).create().show();
                        }
                    }
                } else {
                    if (client != null){
                        client.connect();
                    }
                }
                break;
        }
//        if (requestCode == 1 && permissions.length > 0 && ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED){
//            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,500,50,locationListener);
//        }
    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    @Override
    public void onLocationChanged(@NonNull Location location) {
        userLocationDetails = findViewById(R.id.txtUserLocationDetails);
        if (location != null){
            userLocationDetails.setText(
                        MessageFormat.format("Lat: {0} Lon: {1}",
                                location.getLatitude(), location.getLongitude()));
        }
    }

    //sets user details to given details that were filled in the settings page
    public void setUserDetails(String firstName,String lastName,String carModel,String carID){
        this.firstName = firstName;
        this.lastName = lastName;
        this.carModel = carModel;
        this.carID = carID;
    }

    //TODO:shared preferences implemented but did not find any usage
    //shared preferences section
    public void saveData(){
        sharedPreferences = getSharedPreferences("saveData", Context.MODE_PRIVATE);
        //isAutoRefreshOn = autoRefreshButton.isActivated();

        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("key first name",firstName);
        editor.putString("key last name",lastName);
        editor.putString("key car model",carModel);
        editor.putString("key car id",carID);
        editor.putBoolean("key is auto refresh on",isAutoRefreshOn);
        editor.apply();
        Toast.makeText(getApplicationContext(),"Your data is saved",Toast.LENGTH_LONG).show();
    }

    //TODO: part of the unfinished "shared preferences" section
    @SuppressLint("SetTextI18n")
    public void retrieveData(){
        sharedPreferences = getSharedPreferences("saveData",MODE_PRIVATE);
        firstName = sharedPreferences.getString("key first name",null);
        lastName = sharedPreferences.getString("key last name",null);
        carModel = sharedPreferences.getString("key car model",null);
        carID = sharedPreferences.getString("key car id",null);
        isAutoRefreshOn = sharedPreferences.getBoolean("key is auto refresh on",false);

        userDetails.setText("First Name : " + firstName +
                "\nLast Name : " + lastName +
                "\nCar Model : " + carModel +
                "\nCar ID : " + carID);

    }

    //the function that pops up when the menu is selected
    public void showPopupMenu(){
        View optionsMenu = findViewById(R.id.options_menu);
        PopupMenu popupMenu = new PopupMenu(this,optionsMenu);
        popupMenu.setOnMenuItemClickListener(this);
        popupMenu.inflate(R.menu.popup_menu);
        popupMenu.show();
    }

    //for importing the created menu
    @Override
    public boolean onCreateOptionsMenu(@NonNull Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu,menu);
        return true;
    }

    //for returning a result when an item is selected in the menu
    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.settings_menu:
                Toast.makeText(this, "Settings Selected", Toast.LENGTH_SHORT).show();
                goToSettings();
                return true;
            case R.id.options_menu:
                showPopupMenu();
                Toast.makeText(this, "Options Selected", Toast.LENGTH_SHORT).show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }

    }

    //refer user to the "Settings Page"
    private void goToSettings(){
        startActivity(new Intent(MainActivity.this, com.parkingapp.ParkingSettingsActivity.class));
    }
    //refer user to the "Parking Spots Page"
    private void goToParkingSpots(){
        startActivity(new Intent(MainActivity.this, com.parkingapp.ParkingSpotsActivity.class));
    }
    //refer user to the "Location Management Page"
    private void goToLocationManagementPage(){
        startActivity(new Intent(MainActivity.this, com.parkingapp.ParkingManagementActivity.class));
    }
    //refer user to the "Parking History Page"
    private void goToParkingHistory(){
        startActivity(new Intent(MainActivity.this, com.parkingapp.ParkingHistoryActivity.class));
    }
    //refer user to the "About Us Page"
    private void goToAboutUs(){
        startActivity(new Intent(MainActivity.this, com.parkingapp.ParkingAboutUsActivity.class));
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onMenuItemClick(MenuItem menuItem) {
        switch (menuItem.getItemId()){
            case R.id.option1:
                goToParkingSpots();
                return true;
            case R.id.option2:
                goToLocationManagementPage();
                return true;
            case R.id.option3:
                goToParkingHistory();
                return true;
            case R.id.option4:
                goToAboutUs();
                return true;
            default:
                return false;
        }
    }


}