package com.parkingapp.database;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

//this is our database form and table
@Entity(tableName = "location_table")
public class Location {

    @PrimaryKey(autoGenerate = true)
    public int id;

    public String city;

    public String street_name;

    public int street_num;

    public String dateAndTime = "not defined";


    public Location(String city, String street_name, int street_num) {
        this.city = city;
        this.street_name = street_name;
        this.street_num = street_num;
    }

    public int getId() {
        return id;
    }

    public String getCity() {
        return city;
    }

    public String getStreet_name() {
        return street_name;
    }

    public int getStreet_num() {
        return street_num;
    }

    public String getDateAndTime() {
        return dateAndTime;
    }

    public void setId(int id) {
        this.id = id;
    }
}
