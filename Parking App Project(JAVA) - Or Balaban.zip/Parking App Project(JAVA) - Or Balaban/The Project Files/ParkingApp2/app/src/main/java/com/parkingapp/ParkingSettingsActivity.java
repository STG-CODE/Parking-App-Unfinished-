package com.parkingapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Objects;

public class ParkingSettingsActivity extends AppCompatActivity {

    EditText firstName,lastName,carModel,carID;

    Button save,reset;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        Objects.requireNonNull(getSupportActionBar()).setTitle("Parking App Settings Page");


        firstName = findViewById(R.id.txtEditFirstName);
        lastName = findViewById(R.id.txtEditLastName);
        carModel = findViewById(R.id.txtEditCarModel);
        carID = findViewById(R.id.txtEditCarID);

        save = findViewById(R.id.buttonSaveInput);
        reset = findViewById(R.id.buttonResetToDefault);

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String userFirstName = firstName.getText().toString();
                String userLastName = lastName.getText().toString();
                String userCarModel = carModel.getText().toString();
                String userCarID = carID.getText().toString();

                Intent intent = new Intent(ParkingSettingsActivity.this,MainActivity.class);
                intent.putExtra("userFirstName",userFirstName);
                intent.putExtra("userLastName",userLastName);
                intent.putExtra("userCarModel",userCarModel);
                intent.putExtra("userCarID",userCarID);
                startActivity(intent);

            }
        });

        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

    }
}
