package com.parkingapp;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.parkingapp.database.Location;
import com.parkingapp.database.LocationAdapter;
import com.parkingapp.database.LocationViewModel;

import java.util.List;
import java.util.Objects;

//this class is for presenting the previous locations where the user was parked
public class ParkingHistoryActivity extends AppCompatActivity {

    private LocationViewModel locationViewModel;

    Button save;
    Button reset;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);//sets the title of the page of the app
        Objects.requireNonNull(getSupportActionBar()).setTitle("Parking History Page");
        //our buttons

        //used to save selected location
        save = findViewById(R.id.buttonSaveLocal);
        //used to erase the accumulated locations
        reset = findViewById(R.id.buttonResetLocals);


        //our connection to the recycler view
        RecyclerView recyclerView = findViewById(R.id.recViewHistory);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        //our connection to the adapter
        LocationAdapter adapter = new LocationAdapter();
        recyclerView.setAdapter(adapter);


        locationViewModel = new ViewModelProvider
                .AndroidViewModelFactory(getApplication())
                .create(LocationViewModel.class);

        locationViewModel.getAllLocations().observe(this, new Observer<List<Location>>() {
            @Override
            public void onChanged(List<Location> locations) {

                //used to update our recycler view
                adapter.setLocations(locations);


            }
        });

        //TODO:CREATE A METHOD FOR REACTING TO SELECTION SO THAT IT WILL
        // HIGHLIGHT AND ALSO SAVE AND WHEN SAVE IS CLICKED WILL BE SET AS CURRENT LOCATION

        //action when clicking on "save"
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //TODO:change from static number to selected one
                saveLocation(0);
            }
        });

        //action when clicking on "reset"
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetList();
            }
        });

    }

    //TODO:ONC FINISHED CHANGE TO ID OR POSITION
    //used to save the given location cas current
    public void saveLocation(int position){
//        Intent intent = new Intent();
//        intent.putExtra("selectedLocation", position);
//        setResult(RESULT_OK,intent);
        Toast.makeText(getApplicationContext(),"Saved Selected Location",Toast.LENGTH_SHORT).show();
        finish();
    }

    //used to erase the list and turn it back to zero items or one item which is the current one
    public void resetList(){

        Toast.makeText(getApplicationContext(),"Removed All Saved Locations",Toast.LENGTH_SHORT).show();
        finish();
    }
}
