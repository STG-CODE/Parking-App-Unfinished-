package com.parkingapp.database;

public class AddLocation {




}
