package com.parkingapp.database;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.parkingapp.R;

import java.util.ArrayList;
import java.util.List;

public class LocationAdapter extends RecyclerView.Adapter<LocationAdapter.LocationHolder> {

    private List<Location> locations = new ArrayList<>();
    //needed recycler view methods

    @NonNull
    @Override
    public LocationHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.activity_location_item,parent,false);

        return new LocationHolder(view);
    }

    //TODO:issue might be here
    @Override
    public void onBindViewHolder(@NonNull LocationHolder holder, int position) {

        Location currentLocation = locations.get(position);
        holder.txtTimeAndDate.setText(currentLocation.getDateAndTime());
        holder.txtCityName.setText(currentLocation.getCity());
        holder.txtStreetName.setText(currentLocation.getStreet_name());
        holder.txtStreetNumber.setText(Integer.toString(currentLocation.getStreet_num()));

    }

    @Override
    public int getItemCount() {
        return locations.size();
    }

    @SuppressLint("NotifyDataSetChanged")
    public void setLocations(List<Location> locations){
        this.locations = locations;

        //used to alert the adapter if there is change in the db
        notifyDataSetChanged();
    }

    static class LocationHolder extends RecyclerView.ViewHolder{

        TextView txtTimeAndDate;
        TextView txtCityName;
        TextView txtStreetName;
        TextView txtStreetNumber;

        public LocationHolder(@NonNull View itemView){
            super(itemView);

            txtTimeAndDate = itemView.findViewById(R.id.txtTimeAndDate);
            txtCityName = itemView.findViewById(R.id.txtCityName);
            txtStreetName = itemView.findViewById(R.id.txtStreetName);
            txtStreetNumber = itemView.findViewById(R.id.txtStreetNumber);
        }

    }
}
