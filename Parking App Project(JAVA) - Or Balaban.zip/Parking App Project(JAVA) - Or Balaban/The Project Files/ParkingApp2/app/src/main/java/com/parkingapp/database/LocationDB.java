package com.parkingapp.database;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


//this is our data base class for managing the information
@Database(entities = {Location.class}, version = 1)
public abstract class LocationDB extends RoomDatabase {
    private static LocationDB instance;

    public abstract LocationDao locationDao();

    public static synchronized LocationDB getInstance(Context context){
        if (instance == null){


            instance = Room.databaseBuilder(context.getApplicationContext(),
                    LocationDB.class,"location_database")
                    .fallbackToDestructiveMigration()
                    .addCallback(roomCallBack)
                    .build();
        }

        return instance;
    }

    //creates relation to "Room" db and callback
    private static final Callback roomCallBack = new Callback(){

        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db){
            super.onCreate(db);
            //new PopulateDbAsyncTask(instance).execute();

           LocationDao locationDao = instance.locationDao();

            ExecutorService executorService = Executors.newSingleThreadExecutor();

            //used to populate the db
            executorService.execute(new Runnable() {
                @Override
                public void run() {
                    locationDao.insert(new Location("Rishon Lezion","Hari Ha Hof",12));
                    locationDao.insert(new Location("Rehovot","Zehv Herzel",32));
                    locationDao.insert(new Location("Tel Aviv","Hashomron",3));
                    locationDao.insert(new Location("Eilat","Center Street",5));
                }
            });
        }

    };



    //meant for populating our DB
    //private static class PopulateDbAsyncTask extends AsyncTask<Void,Void,Void>{
        //our local Dao var
        //private Database_LocationDao locationDao;

        //constructor
        //private PopulateDbAsyncTask(Database_LocationDB database){
            //locationDao = database.locationDao();
        //}

        //creates the default data for the database
        //@Override
        //protected Void doInBackground(Void... voids){
            //locationDao.insert(new Database_Location("Rishon Lezion","Hari Ha Hof",12));
            //return null;
        //}

    //}



}
