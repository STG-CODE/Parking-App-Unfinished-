package com.parkingapp.database;

import android.app.Application;

import androidx.lifecycle.LiveData;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class LocationRepository {

    private LocationDao locationDao;
    private LiveData<List<Location>> locations;

    //we use this class in order to use a different thread to avoid error
    ExecutorService executors = Executors.newSingleThreadExecutor();

    public LocationRepository(Application application){

        LocationDB database = LocationDB.getInstance(application);
        locationDao = database.locationDao();
        locations = locationDao.getAllLocations();

    }

    public void insert(Location location){
        //new InsertLocationAsyncTask(locationDao).execute(location);

        //used to replace the Async task and usage
        executors.execute(new Runnable() {
            @Override
            public void run() {
                locationDao.insert(location);
            }
        });
    }

    public void update(Location location){
        //new UpdateLocationAsyncTask(locationDao).execute(location);

        executors.execute(new Runnable() {
            @Override
            public void run() {
                locationDao.update(location);
            }
        });
    }

    public void delete(Location location){
        //new DeleteLocationAsyncTask(locationDao).execute(location);

        executors.execute(new Runnable() {
            @Override
            public void run() {
                locationDao.delete(location);
            }
        });
    }

    public LiveData<List<Location>> getAllLocations(){
        return locations;
    }


    //this is our "Async" method
    //1.the first parameter for doInBackground method
    //2.the second parameter for onProgressUpdate method
    //3.the third parameter return type of doInBackground

    /*
    private static class InsertLocationAsyncTask extends AsyncTask<Database_Location,Void,Void>{

        private Database_LocationDao locationDao;
        private InsertLocationAsyncTask(Database_LocationDao locationDao){
            this.locationDao = locationDao;
        }

        @Override
        protected Void doInBackground(Database_Location...locations){
            locationDao.insert(locations[0]);

            return null;
        }


    }

    private static class UpdateLocationAsyncTask extends AsyncTask<Database_Location,Void,Void>{

        private Database_LocationDao locationDao;
        private UpdateLocationAsyncTask(Database_LocationDao locationDao){
            this.locationDao = locationDao;
        }

        @Override
        protected Void doInBackground(Database_Location... locations){
            locationDao.update(locations[0]);

            return null;
        }


    }

    private static class DeleteLocationAsyncTask extends AsyncTask<Database_Location,Void,Void>{

        private Database_LocationDao locationDao;
        private DeleteLocationAsyncTask(Database_LocationDao locationDao){
            this.locationDao = locationDao;
        }

        @Override
        protected Void doInBackground(Database_Location...locations){
            locationDao.delete(locations[0]);

            return null;
        }


    }

     */
}
