package com.parkingapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.maps.MapView;

import java.util.Objects;

//this class is meant for managing the location where we parked and parking in general with a few options
public class ParkingManagementActivity extends AppCompatActivity {

    TextView currentSavedLocation;
    MapView mapMngView;
    Button setToCurrentLocal,setToOneOfPrev,setToDefault;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parking_management);
        Objects.requireNonNull(getSupportActionBar()).setTitle("Parking Management Page");

        currentSavedLocation = findViewById(R.id.txtMngLocalDetails);



        setToCurrentLocal = findViewById(R.id.buttonSetCurrLocal);
        setToCurrentLocal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(ParkingManagementActivity.this,"Spot Was Set To Current Location",Toast.LENGTH_LONG).show();
                finish();
            }
        });

        setToOneOfPrev = findViewById(R.id.buttonSetToPrevSpot);
        setToOneOfPrev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(ParkingManagementActivity.this,"Please Pick One Of The Following Parking Spots",Toast.LENGTH_LONG).show();
                finish();
            }
        });


        setToDefault = findViewById(R.id.buttonSetToDefaultSpot);
        setToDefault.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(ParkingManagementActivity.this,"Spot Was Set Default Location",Toast.LENGTH_LONG).show();
                finish();
            }
        });

    }
}
