Note : API KEY might be reason why google maps wont work

tried to do as much as possible in the given time but got 
into some issues so couldent finish it all or really test it.

but its mostly working, i didnt have time to create a 
word so i created this out of lack of time :)

most of the explanation can be found in the images in the "The Project Plan"
sense i mostly used that plan that i created as my refrence for the project.

most of the code is also explained or at least should be.

hope it was good enogth :)

NOTE : phone used was Nexus 5X API 33

